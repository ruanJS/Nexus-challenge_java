create PROCEDURE sp_inserir_venda (
    p_id_venda IN NUMBER,
    p_id_produto IN NUMBER,
    p_id_cliente IN NUMBER,
    p_id_vendedor IN NUMBER,
    p_id_tempo IN NUMBER,
    p_quantidade IN NUMBER,
    p_receita IN NUMBER
) IS
BEGIN
    -- Validação de dados
    IF p_quantidade <= 0 THEN
        RAISE_APPLICATION_ERROR(-20007, 'A quantidade deve ser maior que zero.');
    END IF;

    -- Inserção de dados
    INSERT INTO fato_vendas (id_venda, id_produto, id_cliente, id_vendedor, id_tempo, quantidade, receita)
    VALUES (p_id_venda, p_id_produto, p_id_cliente, p_id_vendedor, p_id_tempo, p_quantidade, p_receita);

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE_APPLICATION_ERROR(-20008, 'Erro ao inserir venda.');
END sp_inserir_venda;
/

