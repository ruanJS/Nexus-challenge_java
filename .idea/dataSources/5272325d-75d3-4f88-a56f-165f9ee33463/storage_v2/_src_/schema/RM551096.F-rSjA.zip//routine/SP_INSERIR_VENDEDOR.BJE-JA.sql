create PROCEDURE sp_inserir_vendedor (
    p_id_vendedor IN NUMBER,
    p_nome_vendedor IN VARCHAR2,
    p_regiao IN VARCHAR2
) IS
BEGIN
    -- Inserção de dados
    INSERT INTO dim_vendedor (id_vendedor, nome_vendedor, regiao)
    VALUES (p_id_vendedor, p_nome_vendedor, p_regiao);

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE_APPLICATION_ERROR(-20005, 'Erro ao inserir vendedor.');
END sp_inserir_vendedor;
/

