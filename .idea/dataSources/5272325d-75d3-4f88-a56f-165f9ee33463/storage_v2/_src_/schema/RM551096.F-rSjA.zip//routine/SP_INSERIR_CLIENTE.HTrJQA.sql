create PROCEDURE sp_inserir_cliente (
    p_id_cliente IN NUMBER,
    p_nome_cliente IN VARCHAR2,
    p_endereco IN VARCHAR2,
    p_cidade IN VARCHAR2,
    p_estado IN VARCHAR2,
    p_pais IN VARCHAR2
) IS
BEGIN
    -- Validação de dados
    IF p_pais != 'Brasil' THEN
        RAISE_APPLICATION_ERROR(-20003, 'Somente clientes do Brasil são permitidos.');
    END IF;

    -- Inserção de dados
    INSERT INTO dim_cliente (id_cliente, nome_cliente, endereco, cidade, estado, pais)
    VALUES (p_id_cliente, p_nome_cliente, p_endereco, p_cidade, p_estado, p_pais);

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE_APPLICATION_ERROR(-20004, 'Erro ao inserir cliente.');
END sp_inserir_cliente;
/

