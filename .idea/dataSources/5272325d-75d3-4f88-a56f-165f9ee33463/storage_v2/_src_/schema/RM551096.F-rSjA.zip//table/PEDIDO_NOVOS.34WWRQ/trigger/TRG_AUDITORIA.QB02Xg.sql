create trigger TRG_AUDITORIA
    after insert or update or delete
    on PEDIDO_NOVOS
    for each row
DECLARE
    operacao      VARCHAR2(30);
    nome_usuario  VARCHAR2(100);

BEGIN 
    IF INSERTING THEN 
    operacao := 'INSERT';
ELSIF UPDATING THEN
    operacao := 'UPTADE';
ELSIF DELETING THEN 
    operacao := 'DELETE';
END IF;

nome_usuario := SYS_CONTEXT('USERENV', 'SESSION_USER');

INSERT INTO TB_AUDITORIA
    (tabela, operacao, DATA, USUARIO)
Values
    ('pedido_novos', operacao, sysdate, nome_usuario);
END;
/

