create FUNCTION validar_cep_v2(p_cep VARCHAR2) RETURN BOOLEAN AS
BEGIN
    RETURN REGEXP_LIKE(p_cep, '^\d{5}-\d{3}$');
END;
/

