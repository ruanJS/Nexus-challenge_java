create PROCEDURE sp_inserir_produto (
    p_id_produto IN NUMBER,
    p_nome_produto IN VARCHAR2,
    p_categoria IN VARCHAR2,
    p_preco IN NUMBER
) IS
BEGIN
    -- Validação de dados
    IF p_preco <= 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'O preço deve ser maior que zero.');
    END IF;

    -- Inserção de dados
    INSERT INTO dim_produto (id_produto, nome_produto, categoria, preco)
    VALUES (p_id_produto, p_nome_produto, p_categoria, p_preco);

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE_APPLICATION_ERROR(-20002, 'Erro ao inserir produto.');
END sp_inserir_produto;
/

