create trigger TRG_PEDIDO
    before insert
    on PEDIDO_NOVOS
    for each row
BEGIN
    --Atualiza o status de pedido para "Novo" após a inserção
    IF :NEW.STATUS IS NULL THEN
    :NEW.STATUS := 'Novo Pedido';
    END IF;
END;
/

