create PACKAGE PKG_EXEMPLO AS
  v_count NUMBER := 0;  -- variÃ¡vel pÃºblica
  FUNCTION FUN_VALIDA_NOME2(p_nome IN VARCHAR2) RETURN BOOLEAN;  -- funÃ§Ã£o pÃºblica
  CURSOR cursor_vendas_publi IS select * from tabela_vendas; --cursor pÃºblico
  PROCEDURE PRC_INSERE_PRODUTOS_NOVOS;

  PROCEDURE PRC_INSERE_PEDIDO (				P_COD_PEDIDO             PEDIDO.COD_PEDIDO%TYPE,
                                              P_COD_PEDIDO_RELACIONADO PEDIDO.COD_PEDIDO%TYPE,
                                              P_COD_CLIENTE            PEDIDO.COD_CLIENTE%TYPE,
                                              P_COD_USUARIO            PEDIDO.COD_USUARIO%TYPE,
                                              P_COD_VENDEDOR           PEDIDO.COD_VENDEDOR%TYPE,
                                              P_DAT_PEDIDO             PEDIDO.DAT_PEDIDO%TYPE,
                                              P_DAT_CANCELAMENTO       PEDIDO.DAT_CANCELAMENTO%TYPE,
                                              P_DAT_ENTREGA            PEDIDO.DAT_ENTREGA%TYPE,
                                              P_VAL_TOTAL_PEDIDO       PEDIDO.VAL_TOTAL_PEDIDO%TYPE,
                                              P_VAL_DESCONTO           PEDIDO.VAL_DESCONTO%TYPE,
                                              P_SEQ_ENDERECO_CLIENTE   PEDIDO.SEQ_ENDERECO_CLIENTE%TYPE);  -- procedimento pÃºblico
END PKG_EXEMPLO;
/

