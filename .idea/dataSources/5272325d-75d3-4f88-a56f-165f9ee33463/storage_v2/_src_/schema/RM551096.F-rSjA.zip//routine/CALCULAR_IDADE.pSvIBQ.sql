create PROCEDURE
 calcular_idade(
    data_nascimento IN DATE,
    idade OUT NUMBER
)
IS
BEGIN idade :=
FLOOR(MONTHS_BETWEEN(SYSDATE,
data_nascimento) / 12);
END calcular_idade;
/

