create PROCEDURE sp_inserir_tempo (
    p_id_tempo IN NUMBER,
    p_ano IN NUMBER,
    p_mes IN NUMBER,
    p_dia IN NUMBER,
    p_trimestre IN NUMBER
) IS
BEGIN
    -- Inserção de dados
    INSERT INTO dim_tempo (id_tempo, ano, mes, dia, trimestre)
    VALUES (p_id_tempo, p_ano, p_mes, p_dia, p_trimestre);

    COMMIT;
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        RAISE_APPLICATION_ERROR(-20006, 'Erro ao inserir tempo.');
END sp_inserir_tempo;
/

